import json
import boto3

def lambda_handler(event, context):
    s3_client = boto3.client('s3')
    secrets_manager_client = boto3.client('secretsmanager')

    bucket_name = event['Records'][0]['s3']['bucket']['name']
    file_name = event['Records'][0]['s3']['object']['key']

    # read json manifest
    file_obj = s3_client.get_object(Bucket=bucket_name, Key=file_name)
    file_content = file_obj['Body'].read().decode('utf-8')
    manifest_data = json.loads(file_content)

    # get JediID from Secrets Manager
    secret_name = "jediID"
    secret_response = secrets_manager_client.get_secret_value(SecretId=secret_name)
    jedi_id = secret_response['SecretString']

    # get Jedi info from the manifest
    jedi_info = next((item for item in manifest_data if item["id"] == jedi_id), None)

    if jedi_info:
        return {
            'statusCode': 200,
            'body': json.dumps(jedi_info)
        }
    else:
        return {
            'statusCode': 404,
            'body': json.dumps({"message": "Jedi not found"})
        }